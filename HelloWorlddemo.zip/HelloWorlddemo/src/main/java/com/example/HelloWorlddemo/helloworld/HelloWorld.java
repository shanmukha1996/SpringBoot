package com.example.HelloWorlddemo.helloworld;

import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.context.annotation.Configuration;  
import org.springframework.web.bind.annotation.RestController;  
import org.springframework.web.bind.annotation.PathVariable;  

@Configuration  
/* Controller */
@RestController  
public class HelloWorld   
{  
	/* using get method and hello-world URI  */
	@GetMapping(path="/hello-world")  
	public String helloWorld()  
	{  
		return "Hello World";
	}
	  
	@GetMapping(path="/hello-world-bean")  
	/* method- that returns "Hello World" */
	public HelloWorldBean helloWorldBean()  
	{  
		return new HelloWorldBean("Hello World");/* constructor of HelloWorldBean  */
	} 
	 
	/* passing path variable  */
	@GetMapping(path="/hello-world/path-variable/{variable}")  
	public HelloWorldBean helloWorldPathVariable(@PathVariable("variable") String variable)  
	{  
		return new HelloWorldBean(String.format("Hello World, %s", variable)); /* %s replace the variable */
	}  
}  

